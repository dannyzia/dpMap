@echo off
REM Edit these two lines before sharing the tool with anyone.
set ADMIN_PASSWORD=change-me-now
set CONTRIBUTOR_KEY=
node server.js
pause

# dpMaps POI tool

Contributors open a map, tap where a place is, enter its Bangla and English name, pick a category, and save.
You review pins at /admin and export approved ones as GeoJSON or CSV.

## Run (Windows)
1. Install Node.js 20 or newer from https://nodejs.org
2. Open a terminal in this folder and run: npm install
3. Edit start.bat and set ADMIN_PASSWORD (and CONTRIBUTOR_KEY if you will share the link)
4. Double-click start.bat
5. Contributors: http://localhost:3000
   Admin (user: admin): http://localhost:3000/admin

Data is stored in pois.db next to server.js. Back it up by copying that file.

const express = require('express');
const Database = require('better-sqlite3');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'change-me';
const CONTRIBUTOR_KEY = process.env.CONTRIBUTOR_KEY || '';
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'pois.db');

const CATEGORIES = [
  ['mall', 'Shopping mall'],
  ['market', 'Market / bazaar'],
  ['university', 'University / college'],
  ['school', 'School'],
  ['hospital', 'Hospital / clinic'],
  ['station', 'Metro / bus / rail station'],
  ['airport', 'Airport / launch ghat'],
  ['hotel', 'Hotel / guest house'],
  ['restaurant', 'Restaurant / cafe'],
  ['bank', 'Bank / ATM'],
  ['office', 'Office / business park'],
  ['park', 'Park / playground'],
  ['mosque', 'Mosque'],
  ['worship', 'Other place of worship'],
  ['government', 'Government office'],
  ['area', 'Neighborhood / area name'],
  ['landmark', 'Landmark / intersection'],
  ['other', 'Other']
];
const CATEGORY_KEYS = new Set(CATEGORIES.map(c => c[0]));

// Rough bounding box of Bangladesh
const BBOX = { minLat: 20.5, maxLat: 26.7, minLng: 88.0, maxLng: 92.8 };
const DUP_RADIUS_M = 50;

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS pois (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name_bn TEXT NOT NULL DEFAULT '',
  name_en TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL,
  lat REAL NOT NULL,
  lng REAL NOT NULL,
  notes TEXT NOT NULL DEFAULT '',
  contributor TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_pois_status ON pois(status);
CREATE INDEX IF NOT EXISTS idx_pois_latlng ON pois(lat, lng);
`);

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '20kb' }));

// ---------- helpers ----------
function sha(s) { return crypto.createHash('sha256').update(String(s)).digest(); }
function safeEqual(a, b) { return crypto.timingSafeEqual(sha(a), sha(b)); }

function requireAdmin(req, res, next) {
  const h = req.headers.authorization || '';
  if (h.startsWith('Basic ')) {
    const decoded = Buffer.from(h.slice(6), 'base64').toString('utf8');
    const i = decoded.indexOf(':');
    const user = decoded.slice(0, i);
    const pass = decoded.slice(i + 1);
    if (i >= 0 && safeEqual(user, 'admin') && safeEqual(pass, ADMIN_PASSWORD)) return next();
  }
  res.set('WWW-Authenticate', 'Basic realm="dpMaps admin"');
  res.status(401).send('Authentication required');
}

function distanceM(lat1, lng1, lat2, lng2) {
  const R = 6371000, rad = Math.PI / 180;
  const dLat = (lat2 - lat1) * rad, dLng = (lng2 - lng1) * rad;
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}
const norm = s => String(s || '').trim().toLowerCase().replace(/\s+/g, ' ');
const clean = (s, max) => String(s == null ? '' : s).trim().replace(/\s+/g, ' ').slice(0, max);

function findDuplicate(lat, lng, name_bn, name_en, excludeId = 0) {
  const d = 0.001; // about 110 m
  const rows = db.prepare(
    `SELECT * FROM pois WHERE status != 'rejected' AND id != ?
     AND lat BETWEEN ? AND ? AND lng BETWEEN ? AND ?`
  ).all(excludeId, lat - d, lat + d, lng - d, lng + d);
  const nb = norm(name_bn), ne = norm(name_en);
  return rows.find(r =>
    distanceM(lat, lng, r.lat, r.lng) <= DUP_RADIUS_M &&
    ((nb && norm(r.name_bn) === nb) || (ne && norm(r.name_en) === ne))
  );
}

// Tiny in-memory rate limiter for contributor saves
const hits = new Map();
function rateLimit(req, res, next) {
  const key = req.ip, now = Date.now(), windowMs = 60 * 60 * 1000, max = 200;
  const arr = (hits.get(key) || []).filter(t => now - t < windowMs);
  if (arr.length >= max) return res.status(429).json({ error: 'Too many saves. Try again later.' });
  arr.push(now); hits.set(key, arr); next();
}

function validatePoi(body, partial = false) {
  const out = {};
  if (!partial || 'name_bn' in body) out.name_bn = clean(body.name_bn, 120);
  if (!partial || 'name_en' in body) out.name_en = clean(body.name_en, 120);
  if (!partial || 'category' in body) out.category = clean(body.category, 30);
  if (!partial || 'notes' in body) out.notes = clean(body.notes, 500);
  if (!partial || 'lat' in body) out.lat = Number(body.lat);
  if (!partial || 'lng' in body) out.lng = Number(body.lng);
  if ('category' in out && !CATEGORY_KEYS.has(out.category)) return { error: 'Pick a category.' };
  if ('lat' in out || 'lng' in out) {
    if (!Number.isFinite(out.lat) || !Number.isFinite(out.lng) ||
        out.lat < BBOX.minLat || out.lat > BBOX.maxLat ||
        out.lng < BBOX.minLng || out.lng > BBOX.maxLng) {
      return { error: 'Pin is outside Bangladesh. Tap the map to place it again.' };
    }
  }
  return { value: out };
}

// ---------- public API ----------
app.get('/api/config', (req, res) => {
  res.json({
    categories: CATEGORIES.map(([key, label]) => ({ key, label })),
    needsKey: !!CONTRIBUTOR_KEY
  });
});

app.get('/api/pois', (req, res) => {
  const rows = db.prepare(
    `SELECT id, name_bn, name_en, category, lat, lng, status FROM pois WHERE status != 'rejected'`
  ).all();
  res.json(rows);
});

app.post('/api/pois', rateLimit, (req, res) => {
  if (CONTRIBUTOR_KEY && !safeEqual(req.headers['x-contributor-key'] || '', CONTRIBUTOR_KEY)) {
    return res.status(401).json({ error: 'Wrong access key.' });
  }
  const { value, error } = validatePoi(req.body || {});
  if (error) return res.status(400).json({ error });
  if (!value.name_bn && !value.name_en) {
    return res.status(400).json({ error: 'Enter the place name in Bangla or English.' });
  }
  const dup = findDuplicate(value.lat, value.lng, value.name_bn, value.name_en);
  if (dup) {
    return res.status(409).json({
      error: `"${dup.name_bn || dup.name_en}" is already pinned within ${DUP_RADIUS_M} m.`,
      duplicate: { id: dup.id, lat: dup.lat, lng: dup.lng }
    });
  }
  const contributor = clean(req.body.contributor, 60);
  const info = db.prepare(
    `INSERT INTO pois (name_bn, name_en, category, lat, lng, notes, contributor)
     VALUES (@name_bn, @name_en, @category, @lat, @lng, @notes, @contributor)`
  ).run({ ...value, contributor });
  res.status(201).json({ id: info.lastInsertRowid });
});

// ---------- admin ----------
app.get(['/admin', '/admin.html'], requireAdmin, (req, res) =>
  res.sendFile(path.join(__dirname, 'private', 'admin.html')));

app.get('/api/admin/pois', requireAdmin, (req, res) => {
  const status = req.query.status;
  const rows = status && status !== 'all'
    ? db.prepare('SELECT * FROM pois WHERE status = ? ORDER BY id DESC').all(String(status))
    : db.prepare('SELECT * FROM pois ORDER BY id DESC').all();
  const counts = Object.fromEntries(
    db.prepare('SELECT status, COUNT(*) AS n FROM pois GROUP BY status').all().map(r => [r.status, r.n])
  );
  res.json({ rows, counts });
});

app.patch('/api/admin/pois/:id', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM pois WHERE id = ?').get(id);
  if (!existing) return res.status(404).json({ error: 'Not found' });
  const body = req.body || {};
  const { value, error } = validatePoi(body, true);
  if (error) return res.status(400).json({ error });
  if ('status' in body) {
    if (!['pending', 'approved', 'rejected'].includes(body.status)) {
      return res.status(400).json({ error: 'Bad status' });
    }
    value.status = body.status;
  }
  const keys = Object.keys(value);
  if (!keys.length) return res.json({ ok: true });
  const sets = keys.map(k => `${k} = @${k}`).join(', ');
  db.prepare(`UPDATE pois SET ${sets}, updated_at = datetime('now') WHERE id = @id`).run({ ...value, id });
  res.json({ ok: true });
});

app.delete('/api/admin/pois/:id', requireAdmin, (req, res) => {
  db.prepare('DELETE FROM pois WHERE id = ?').run(Number(req.params.id));
  res.json({ ok: true });
});

function exportRows(req) {
  const status = req.query.status || 'approved';
  return status === 'all'
    ? db.prepare('SELECT * FROM pois ORDER BY id').all()
    : db.prepare('SELECT * FROM pois WHERE status = ? ORDER BY id').all(String(status));
}

app.get('/api/admin/export.geojson', requireAdmin, (req, res) => {
  const rows = exportRows(req);
  res.set('Content-Disposition', 'attachment; filename="pois.geojson"');
  res.json({
    type: 'FeatureCollection',
    features: rows.map(r => ({
      type: 'Feature',
      geometry: { type: 'Point', coordinates: [r.lng, r.lat] },
      properties: {
        id: r.id, name_bn: r.name_bn, name_en: r.name_en, category: r.category,
        notes: r.notes, contributor: r.contributor, status: r.status, created_at: r.created_at
      }
    }))
  });
});

app.get('/api/admin/export.csv', requireAdmin, (req, res) => {
  const rows = exportRows(req);
  const cols = ['id', 'name_bn', 'name_en', 'category', 'lat', 'lng', 'notes', 'contributor', 'status', 'created_at'];
  const cell = v => {
    let s = String(v == null ? '' : v);
    if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // block spreadsheet formula injection
    return '"' + s.replace(/"/g, '""') + '"';
  };
  const lines = [cols.join(',')].concat(rows.map(r => cols.map(c => cell(r[c])).join(',')));
  res.set('Content-Type', 'text/csv; charset=utf-8');
  res.set('Content-Disposition', 'attachment; filename="pois.csv"');
  res.send('\uFEFF' + lines.join('\r\n')); // BOM so Excel reads Bangla correctly
});

// ---------- static (contributor page) ----------
app.use(express.static(path.join(__dirname, 'public')));

app.listen(PORT, () => {
  console.log(`dpMaps POI tool running:  http://localhost:${PORT}`);
  console.log(`Admin review page:        http://localhost:${PORT}/admin  (user: admin)`);
  if (ADMIN_PASSWORD === 'change-me') {
    console.log('WARNING: using the default admin password. Set ADMIN_PASSWORD before sharing this with anyone.');
  }
  if (!CONTRIBUTOR_KEY) {
    console.log('Note: no CONTRIBUTOR_KEY set, so anyone with the link can add pins.');
  }
});
